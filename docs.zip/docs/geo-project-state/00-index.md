# GEO Analyzer — Documentation Index

This folder contains the system-level documentation for the GEO Analyzer.

---

## 📂 Structure Overview

### 01 — Project Overview
`01-project-overview.md`
- High-level introduction of the GEO Analyzer
- Purpose, goals, and system architecture

---

### 02 — Analysis System
`02-analysis-system.md`
- Core concepts of GEO analysis
- Paragraph analysis logic
- LLM (Gemini) citation evaluation
- Key data types

---

### 03 — Scoring System
`03-scoring-system.md`
- GEO score calculation logic
- Weighting system
- Rule-based scoring (structure, trust, answerability)

---

### 04 — Recommendation System ⭐️
`04-recommendation-system.md`
- AI strategy generation logic
- pageSignals definition
- Decision logic (page type & subtype)
- Recommendation rules
- Gemini usage, fallback, rate limit handling
- Output schema

---

### 05 — Analysis Pipeline
`05-pipeline.md`
- End-to-end flow (runAnalysis)
- Data flow from HTML → scoring → result

---

### 06 — UI and Cache
`06-ui-and-cache.md`
- UI structure (AuditPanel, Dashboard, iframe overlay)
- Supabase caching strategy (24h TTL)
- Environment variables

---

### 07 — Reference
`07-reference.md`
- External references
- Config files
- Related implementation notes

---

### 09 — GEO Research Policy
`09-geo-research-policy.md`
- Research source priority (academic-first)
- Recommended weight distribution for GEO criteria generation
- How academic, official, industry, and trend inputs relate to `reference_sources` and `geo_scoring_config`

---

### 10 — Scoring & Issue Philosophy
`10-scoring-issue-philosophy.md`
- Monthly `geo_scoring_config` as source of truth vs branch-specific scoring (web / commerce / video)
- Layered issue model (core + page-type + monthly) and product focus on citation optimization, not SEO-only errors

---

### 11 — System Philosophy & Architecture Rules
`11-system-philosophy-and-architecture-rules.md`
- Authoritative project rules: monthly config, branch-based scoring pipeline, page-type logic, layered issue model, product philosophy, GEO score definition, end-to-end architecture reminder
- Companion Cursor rule: `.cursor/rules/geo-analyzer-architecture.mdc` (always apply)

---

### 12 — Issue System & Score Impact Rules
`12-issue-system-page-type-rules.md`
- Layered issues (core + page-type + monthly); categories; issue→axis impact mapping; severity vs score impact
- Page-type focus (editorial / video / commerce); principle: scoring computes, issues explain
- §7 quick reference: composition, axes, severity shorthand, canonical framing

---

## 🧠 System Layers

The project is structured into three main layers:

1. **Analysis Layer**
   → Extracts and evaluates content

2. **Scoring Layer**
   → Converts signals into GEO scores

3. **Recommendation Layer**
   → Generates actionable strategies for optimization

---

## 📌 Notes

- This structure is designed to reduce fragmentation and improve clarity
- Each document follows a single-responsibility principle
- Recommendation system is separated from scoring for flexibility and scalability