# 03 — Scoring System

This document describes how GEO scores are computed for different page families. It is an **architecture** document: GEO scoring is a multi-stage, branch-based pipeline—not a single universal percentage table. It explains why citation and extractability matter, how monthly configuration changes weights and rules, and how editorial, commerce, and video pages follow different scoring logic.

For **architecture and product philosophy** (monthly config, commerce/video branches, layered issues), see **`10-scoring-issue-philosophy.md`**.

## Scoring Philosophy

GEO scoring is designed to approximate how AI systems select, summarize, and cite content.

The system is driven by a **monthly AI-generated GEO configuration** stored in Supabase.
This configuration defines scoring weights, rule priorities, and page-type emphasis.

Important:  
**GEO scoring does not use one fixed universal formula.**  
The final score is computed through a branch-based pipeline depending on:

- page type (editorial / commerce / video)
- citation availability
- authority signals
- question coverage signals

The goal of GEO scoring is not traditional ranking,
but estimating **AI answer selection probability**.

Key principles:

- Citation likelihood is the primary signal  
- Structural and trust signals support extractability and credibility  
- Rule-based scoring and LLM-based scoring are combined  
- Page type influences scoring weights and overrides  

## Scoring Architecture Overview

The scoring pipeline follows this general flow:

1. Load active GEO scoring config from Supabase  
2. Detect page type (editorial / commerce / video)  
3. Compute partial scores:  
   - citation  
   - paragraph quality  
   - answerability  
   - structure  
   - trust  
   - question coverage / question match  
4. Apply page-type specific blending or overrides  
5. Apply caps / bonuses based on authority and AI citation evidence  
6. Produce `finalScore`  

Therefore, GEO scoring should be understood as a **multi-stage scoring system**, not a single equation.

## A. General web pages

| Axis | How it's computed | Typical weight |
|---|---|---|
| citationScore | Gemini chunk scoring + authority/data adjustments | ~45% |
| paragraphScore | paragraphStats: definition ratio, ideal length, infoDensity | ~10% |
| answerabilityScore | Rule-based: first paragraph, quotable sentences, tables | ~15% |
| structureScore | Title / Description / H1/H2 / OG / Canonical / Schema | 5–15% |
| trustScore | author, publish/modified dates, contact/about links | 5–15% |
| questionCoverage / match | Tavily question coverage and text matching | varies |

### Notes

- `citationScore` is the dominant signal.  
- If citation signals are weak or unavailable, weights shift toward structure, answerability, and trust.  
- Authority signals and real AI citations may increase score ceilings.  

## B. YouTube (video)

YouTube pages use a dedicated pipeline aligned with how models use **video metadata** (not full page HTML) as a source:

- metadata-based analysis (title, description, chapters)  
- Gemini-based semantic scoring  
- information density from description  
- search question coverage  
- recommendation / comparison signals in description  

This pipeline differs from standard HTML-based analysis and uses **video-specific weights** from the active GEO profile when present (`profiles.video` / `profiles.video.weights` in `GeoScoringConfig`, typically from Supabase `geo_scoring_config`). The emphasis is still on **what an AI can extract and cite** from title and description, not on classic on-page SEO alone.

## C. Commerce / e-commerce

Commerce pages prioritize **data density, structure, and trust** over editorial-style citation signals.

Key signals:

- product schema (JSON-LD)  
- price visibility  
- spec tables  
- shipping / returns / warranty information  
- review summaries  
- comparison information  

Typical weighting:

- dataDensity / commerceScore: ~40%  
- structureScore: ~30%  
- trustScore: ~20%  
- answerabilityScore: ~10–15%  

Note:

Commerce pages may override the general scoring blend and use a commerce-specific formula.  
`citationScore` is still considered, but usually has lower influence than product data quality.

## Scoring Components

- **LLM-based scoring**  
  - `citationScore` (Gemini-based evaluation)  

- **Rule-based scoring**  
  - `paragraphScore`  
  - `answerabilityScore`  
  - `structureScore`  
  - `trustScore`  

## Final Score Calculation

The final GEO score is **not computed using one fixed formula**.

Instead, the system uses weighted blends that vary depending on:

- page type  
- citation availability  
- authority / AI citation evidence  
- commerce override  
- video pipeline  

In general form:

```
finalScore =
  weightedBlend(
    citationScore,
    paragraphScore,
    answerabilityScore,
    structureScore,
    trustScore,
    questionCoverage,
    questionMatch
  )
```

Weights and blending logic are defined in:

- `src/lib/defaultScoringConfig.ts`  
- Supabase `geo_scoring_config` (loaded via `src/lib/scoringConfigLoader.ts`)  
- `src/lib/runAnalysis.ts`  

### Example (illustrative only)

The numeric blend below shows **one possible** editorial-style weighting. Actual `finalScore` depends on the active profile, branch, and config—it is **not** guaranteed to be a single weighted sum in every path.

- citationScore = 70 (weight ~45%)  
- paragraphScore = 60 (weight ~10%)  
- answerabilityScore = 50 (weight ~15%)  
- structureScore = 80 (weight ~15%)  
- trustScore = 70 (weight ~15%)  

Example blend:  
70×0.45 + 60×0.10 + 50×0.15 + 80×0.15 + 70×0.15  
= 31.5 + 6 + 7.5 + 12 + 10.5 = 67.5 → ~68  

(Weights and values are illustrative; see `defaultScoringConfig.ts`, `geo_scoring_config`, and `runAnalysis.ts` for real behavior.)

## Operational notes

- **Persistence:** analysis outputs (scores/results) are persisted/upserted to Supabase (`analysis_history`) as part of the pipeline for caching and audit.  
- **LLM/quota handling:** LLM errors and quota (429) are handled by the retry layer; 429/quota cases cause immediate fallback and cooldown (see `src/lib/geminiRetry.ts` and `src/lib/llmError.ts`).  
- **Related files:** scoring defaults (`src/lib/defaultScoringConfig.ts`), runtime loader (`src/lib/scoringConfigLoader.ts`).

## Key Principle

GEO Score represents:

> The likelihood that an AI system will select, summarize, or cite this page as an answer source.

Therefore, GEO scoring emphasizes:

- extractable answers  
- structured information  
- trustworthy signals  
- coverage of real search questions  
- citation-worthy paragraphs  
