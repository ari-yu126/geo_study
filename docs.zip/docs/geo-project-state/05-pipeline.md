# 05 — Analysis Pipeline (runAnalysis)

This document describes the end-to-end analysis pipeline executed by `runAnalysis`.

---

## Overview

The analysis pipeline transforms a raw URL into a structured GEO evaluation.

It combines:

- rule-based content analysis  
- LLM-based semantic evaluation (Gemini)  
- external search data (Tavily)  

to compute GEO scores and generate actionable recommendations.

---

## Function Contract

runAnalysis(url: string): Promise<AnalysisResult>

### Input
- `url`: target page URL

### Output
- `AnalysisResult`
  - scores (GEO score breakdown)
  - issues (detected problems)
  - recommendations (actionable improvements)
  - metadata (page info, topic, etc.)

---

## Pipeline Steps

1. **Fetch HTML**  
   - `fetchHtml(url)`  
   - retrieves raw HTML content

2. **Extract metadata and content**  
   - `extractMetaAndContent(html)`  
   - extracts title, description, headings, main content

3. **Detect topic and seed keywords**  
   - `extractSeedKeywords(meta, content)`  
   - determines primary topic and keyword signals

4. **Collect search questions (Tavily)**  
   - `fetchSearchQuestions(primaryTopic)`  
   - collects real-world user/search questions  
   - applies topic filtering and relevance filtering

5. **Parallel execution**

   - **Paragraph analysis**  
     - `analyzeParagraphs(html, headings, searchQuestions)`  
     - rule-based evaluation:
       - definition patterns  
       - information density  
       - duplication  
       - paragraph length  

   - **Citation evaluation (Gemini)**  
     - `evaluateCitations(chunks, searchQuestions)`  
     - semantic evaluation:
       - citation likelihood (0–10)  
       - community fit (0–10)  
       - reasoning  

6. **Compute structural scores**  
   - structureScore  
   - answerabilityScore  
   - trustScore  
   - based on rule-based signals (meta tags, schema, content layout, etc.)

7. **Aggregate final GEO score**  
   - combine all scoring axes:
     - citationScore (LLM-based)
     - paragraphScore
     - answerabilityScore
     - structureScore
     - trustScore  
   - apply dynamic weighting based on page type and signals

8. **Generate recommendations**  
   - `generateGeoRecommendations(...)`  
   - transforms analysis results into actionable improvements:
     - headings (H2/H3)
     - FAQ blocks
     - comparison tables
     - content structure suggestions  

9. **Return result**  
   - returns `AnalysisResult`  
   - used for UI rendering and report generation
   - persist: analysis is upserted to Supabase (`analysis_history`) as part of the pipeline (or immediately after) for caching and audit.

---

## Parallel Execution

Paragraph analysis and citation evaluation are executed in parallel:

- `analyzeParagraphs` → deterministic, rule-based  
- `evaluateCitations` → LLM-based (Gemini)  

This separation:
- reduces latency  
- isolates AI dependency  
- improves system stability  

---

## Gemini Usage

Gemini is used only for semantic evaluation:

- evaluates citation likelihood per paragraph  
- outputs structured scores and reasoning  
- does not control pipeline flow  

All orchestration remains deterministic.

**Operational notes (LLM errors & quota)**  
- 429 / quota errors: do not retry — set a short cooldown and immediately fall back to template recommendations.  
- Non-429 transient errors: may be retried with limited backoff (see retry policy).

---

## Caching

Before executing the pipeline:

- check Supabase for existing analysis results  
- if a recent result exists (within TTL):
  - return cached result  
  - skip Gemini calls to reduce cost  

**Limited-analysis / short HTML**  
- If analysis is limited (bot protection, very short HTML, etc.), Gemini calls can be skipped and template-based recommendations (isTemplateFallback) used instead.
---

## Related Files

- Pipeline orchestration:  
  - `src/lib/runAnalysis.ts`

- Paragraph analysis:  
  - `src/lib/paragraphAnalyzer.ts`

- Citation evaluation (Gemini):  
  - `src/lib/citationEvaluator.ts`

- Scoring logic:  
  - `src/lib/defaultScoringConfig.ts`  
  - `src/lib/scoringConfigLoader.ts`

- Recommendation engine:  
  - `src/lib/recommendationEngine.ts`
 - Gemini retry & error handling:
   - `src/lib/geminiRetry.ts`
   - `src/lib/llmError.ts`