# GEO Research Source Policy

## Overview

The GEO (Generative Engine Optimization) scoring model must be based on reliable and explainable research sources. To ensure consistency and credibility, GEO criteria are generated using a weighted mix of academic research, official documentation, and industry/trend sources.

This policy defines how research sources are prioritized when generating GEO scoring configurations.

## Research Source Priority

The GEO model should follow an academic-first research strategy:

1. Academic Research (primary foundation)
2. Official Documentation and Standards
3. Authority Industry Sources
4. Trend and Web Research (supplement only)

## Recommended Weight Distribution

The GEO research input should approximately follow this weighting:

| Source Type | Purpose | Weight |
|-------------|---------|--------|
| Academic Papers | Core ranking and citation theory, IR, RAG, semantic search | 60% |
| Official Docs / Standards | Structured data, search engine guidelines, platform docs | 30% |
| Industry / Trend / Web Research | Emerging GEO trends, SEO practices, user search behavior | 10% |

This distribution is not strict but should guide how research sources are selected and summarized.

## Per-page-type weighting (monthly `geo_scoring_config`)

When generating scoring **profiles** (editorial / video / commerce), the same raw sources are allocated with **profile-specific** mixes. Implementation: `GEO_CRITERIA_PAGE_TYPE_RESEARCH_WEIGHTS` in `src/lib/geoCriteriaResearch/pageTypeResearchWeights.ts`; Gemini receives **separate truncated corpora** per profile via `formatPageTypeWeightedResearchForGemini` (academic-first; official and industry share the “official+authority” budget by relative length).

| Profile | Academic | Official + authority industry | Trend |
|---------|----------|----------------------------------|-------|
| editorial | 60% | 30% | 10% |
| commerce | 50% | 40% | 10% |
| video | 50% | 40% | 10% |

The **default** profile uses the same mix as **editorial** unless the model justifies a neutral blend.

## Source Type Definitions

### Academic Sources

Examples:

- Information Retrieval papers
- Search engine ranking research
- Citation analysis papers
- Semantic search / RAG papers
- arXiv / Semantic Scholar / OpenAlex papers
- HCI / QA / Knowledge retrieval research

These sources define the theoretical foundation of GEO scoring.

### Official Documentation

Examples:

- Google Search Central
- Schema.org
- W3C
- Platform developer documentation
- Official AI platform documentation

These sources define technical implementation and structured data best practices.

### Authority Industry Sources

Examples:

- Search Engine Journal
- Ahrefs
- Moz
- Semrush
- McKinsey
- Bain
- Nielsen
- Large research reports

These sources define industry practices and applied SEO/GEO strategies.

### Trend / Web Research

Examples:

- Tavily search results
- Blog posts
- Recent GEO discussions
- AI search changes
- Emerging practices

These sources should be used only as trend signals, not as primary GEO criteria.

## GEO Criteria Generation Philosophy

When generating GEO scoring criteria:

- Academic research defines **why** ranking and citation happen.
- Official documentation defines **how** content should be structured.
- Industry sources define **what** works in practice.
- Trend research defines **what is changing** recently.

In short:

- Academic → Foundation
- Official → Implementation
- Industry → Practical Strategy
- Trend → Adjustment

## GEO System Knowledge Pipeline

The GEO system should follow this knowledge pipeline:

```text
Research Sources
    ↓
reference_sources (database)
    ↓
LLM generates GEO scoring model
    ↓
geo_scoring_config
    ↓
Page analysis
    ↓
geo_analysis_results
```

This ensures the GEO scoring system is research-based, explainable, and version-controlled.

## Summary

The GEO scoring model must follow an academic-first, documentation-supported, trend-adjusted research strategy.

**Priority order:**

```text
Academic Research
    → Official Documentation
        → Authority Industry Sources
            → Trend / Web Research
```

This policy ensures the GEO system remains stable, explainable, and aligned with real AI search behavior.
