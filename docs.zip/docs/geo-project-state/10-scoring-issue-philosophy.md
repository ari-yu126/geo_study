# 10 — GEO Analyzer Scoring & Issue System Philosophy

## Monthly configuration as source of truth

This project uses a **monthly AI-generated GEO configuration** stored in Supabase (`geo_scoring_config`). That monthly config is the **primary source of truth** for:

- scoring profiles  
- weights  
- structure / answerability / trust rule sets  
- issue rule priorities  
- page-type emphasis for editorial / commerce / video  

See also: `09-geo-research-policy.md` (how that config is researched), `03-scoring-system.md` (mechanics), `12-issue-system-page-type-rules.md` (issues vs score axes and impact rules).

---

## Branch-specific scoring (not a single static formula)

**Final GEO scoring is not one fixed formula.** The application uses **branch-specific** scoring logic depending on **page type** and **signal availability** (citation present, chunk quality, commerce, video, etc.).

### 1. Shared config loading

- Always load the **active** `geo_scoring_config` from Supabase.  
- **Fallback** to `DEFAULT_SCORING_CONFIG` when missing or incomplete.  
- This config provides `structureRules`, `answerabilityRules`, `trustRules`, and **profile weights** (`profiles`).

Implementation: `src/lib/scoringConfigLoader.ts`, `src/lib/defaultScoringConfig.ts`.

### 2. General web analysis

`runAnalysis` computes partial scores for:

- **citation** — Gemini chunk evaluation (plus documented floors/bonuses for data/authority/FAQ, etc.)  
- **paragraph quality** — paragraph stats → score  
- **structure** — rule-based from config  
- **answerability** — rule-based from config  
- **trust** — rule-based from config  
- **question coverage / question match** — Tavily search questions vs page content  

**`finalScore`** is a **weighted blend** of these signals. Weighting **changes** depending on:

- whether **`citationScore` is available / meaningful**  
- **strong citation chunk quality** (dynamic adjustment of citation vs structure/trust weights)  
- **commerce**, **FAQ-like**, and **trust caps** as implemented in `runAnalysis.ts`  

### 3. Commerce override

If `pageType === 'commerce'`, **`finalScore` is overridden** by a **commerce-specific** blend. Commerce scoring is primarily driven by:

- **data density** (price/spec/card signals)  
- **structure**  
- **trust** (including schema/OG boosts as coded)  

### 4. YouTube / video pipeline

- YouTube uses a **dedicated pipeline** (not the same path as generic HTML).  
- **`finalScore`** is derived from description quality, video analysis, search question coverage, and **video profile weights**.  
- Use **`profiles.video.weights`** when present; otherwise **fallback defaults** in code (`geminiVideoAnalysis.ts` / related).

---

## Issue detection philosophy

Monthly GEO config should influence **both scores and issues**. However, **issues must remain explainable and stable** even if the monthly config is incomplete.

### Layered issue model (target architecture)

Issue detection should follow this **layered** model:

1. **Core minimum issue rules** — safety net for explainability  
2. **Page-type base issue rules** — structural relevance (editorial vs commerce vs video)  
3. **Monthly GEO issue rules** — emphasis from `geo_scoring_config`  

Conceptually:

```text
finalIssueRules =
    coreMinimumRules
  + pageTypeBaseRules
  + monthlyGeoIssueRules
```

**Important:**

- **Monthly config** drives the main GEO logic.  
- **Core rules** are a **safety net** so the analyzer always has explainable findings.  
- **Page-type base rules** ensure **structural relevance**.  
- **Monthly rules** extend or shift emphasis; they should **not** leave the analyzer with **near-zero explainable issues** when the page is weak.  

Current implementation merges config-driven `issueRules` with defaults in `issueDetector.ts`; evolving toward explicit core + page-type + monthly layers is a **product direction** aligned with this document.

---

## Product philosophy

This is **not only an SEO audit tool**. It is an **AI citation / recommendation optimization** analyzer.

The UI and logic should emphasize:

- **strengths**  
- **missing signals**  
- **weak signals**  
- **improvement opportunities**  
- **explainable issues**  

—not only raw “errors”.

Passed checks, recommendations, and issue copy should reinforce **actionable GEO improvement**, not checklist-only scoring.
