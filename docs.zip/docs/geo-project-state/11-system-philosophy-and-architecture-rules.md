# GEO Analyzer Project — System Philosophy and Architecture Rules

This project is a GEO (Generative Engine Optimization) analyzer. It evaluates how likely a page is to be cited, summarized, or recommended by AI systems.

This system is **not** a traditional SEO audit tool. It is an **AI citation / recommendation optimization** analyzer.

When modifying scoring, issue detection, or UI logic, follow the architecture and philosophy below.

---

## 1. Monthly GEO Configuration

The system uses a monthly AI-generated GEO configuration stored in **Supabase**.

This configuration is the **primary source of truth** for:

- scoring weights  
- evaluation priorities  
- structure / answerability / trust rules  
- page-type profile weights  
- monthly GEO issue rules  

Always load scoring configuration using the **active** `geo_scoring_config`. Fallback to `DEFAULT_SCORING_CONFIG` when missing.

Monthly GEO config drives scoring behavior, but the system must remain **stable** if the config is incomplete.

---

## 2. Scoring Architecture (Important)

GEO scoring does **not** use one fixed formula.

The final score is computed through a **branch-based pipeline**:

**General flow:**

1. Load scoring config  
2. Detect page type (editorial / commerce / video)  
3. Compute partial scores: citation, paragraph quality, answerability, structure, trust, question coverage / match  
4. Apply page-type scoring branch: general web blend, commerce override, or YouTube/video pipeline  
5. Apply authority / AI citation caps or boosts  
6. Produce `finalScore`  

Do **not** implement scoring as a single static equation. Always respect page-type branching logic.

---

## 3. Page Type Scoring Logic

**General web pages:**  
Weighted blend of citation, paragraph, answerability, structure, trust, question coverage.

**Commerce pages:**  
Final score may override the general blend and prioritize:

- data density  
- structure  
- trust  
- product information quality  

**YouTube / video:**  
Use the dedicated video pipeline:

- description quality  
- chapters  
- video semantic analysis  
- question coverage  
- video profile weights  

---

## 4. Issue Detection Philosophy

Issues must be **explainable** and **stable**. Do **not** rely only on monthly AI-generated issue rules.

Issue rules follow a **layered model**:

```
finalIssueRules =
    coreMinimumRules
  + pageTypeBaseRules
  + monthlyGeoIssueRules
```

Where:

- **coreMinimumRules** — always present rules  
- **pageTypeBaseRules** — editorial / video / commerce base rules  
- **monthlyGeoIssueRules** — AI-generated monthly rules  

Monthly GEO rules should **extend** the system, not replace all issue rules.

If monthly config is missing `issueRules`, fallback to `DEFAULT_SCORING_CONFIG.issueRules`.

---

## 5. Product Philosophy

This tool is **not** an SEO error checker.

The system should explain:

- strengths  
- missing signals  
- weak signals  
- improvement opportunities  
- explainable issues  

The goal is to increase **AI citation and recommendation probability**, not just fix technical errors.

UI and analysis logic should focus on: **AI answerability**, **extractability**, **trust**, and **citation likelihood**.

---

## 6. GEO Score Definition

GEO Score represents:

> The likelihood that an AI system will select, summarize, or cite this page as an answer source.

Scoring should reflect:

- extractable answers  
- structured information  
- trustworthy signals  
- question coverage  
- citation-worthy paragraphs  
- page-type specific signals  

---

## 7. Architecture Reminder

Do **not** describe GEO scoring as a single formula. It is a **pipeline**:

`config` → feature extraction → partial scores → page-type branch → weighted blend or override → `finalScore` → issue detection → recommendations → persistence

Maintain this architecture when modifying code.

---

## Quick reference — GEO Analyzer rules

- Monthly `geo_scoring_config` is the main scoring configuration.  
- Scoring is **branch-based** (general / commerce / video), not a single formula.  
- `finalScore` is computed after partial scores and page-type branching.  
- Issues must use **layered rules**: core + page-type + monthly.  
- This is **not** an SEO audit tool; it is an **AI citation optimization** analyzer.  
- Focus on strengths, missing signals, weak signals, and explainable issues.  
- GEO score represents **AI citation / recommendation likelihood**.  

**Summary:** This system evaluates AI citation and recommendation likelihood, not traditional SEO ranking. Scoring is pipeline-based and page-type dependent, not a single universal formula.
